# SociQl — Site vitrine premium (React + Vite + Tailwind + Framer Motion)

## Lancer en local
```bash
npm install
npm run dev
# Ouvre http://localhost:5173
```

## Build & preview
```bash
npm run build
npm run preview
```

## Déployer (recommandé : Vercel)
1. Crée un repo Git et pousse le code.
2. Sur vercel.com, **New Project** → importe ce repo.
3. Framework: **Vite** (détection auto). Commande de build: `vite build`. Dossier: `dist/`.
4. Ajoute ton domaine → HTTPS automatique.

## Modifier le site
- Page principale : `src/App.jsx`
- Styles globaux : `src/index.css`
- Images des réalisations : place tes fichiers dans `public/projects/` (mêmes noms que dans `App.jsx`), sinon des fallbacks s’affichent.
- Lien Agenda : modifie la constante `CAL_URL` en haut de `src/App.jsx`.

## SEO (rapide)
- Modifie le `<title>` et la meta description dans `index.html`.
- Ajoute `/public/og.jpg` et les balises OG si besoin.

## Besoin d’aide ?
Tu peux me demander d’ajouter un bandeau cookies, GA4, sitemap/robots, schema.org (FAQPage), etc.
